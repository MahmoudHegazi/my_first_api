from flask import Flask, jsonify, request, abort, make_response
import os
import json
from werkzeug.utils import secure_filename
from flask_cors import CORS, cross_origin
from flask_sqlalchemy import SQLAlchemy
from .models import setup_db, Book, db

book_per_page = 8


def create_app(test_config=None):
    app = Flask(__name__,instance_relative_config=True)
    setup_db(app)
    CORS(app)
    # any request on /api from out soruce any domain will accepted but not allow put
    cors = CORS(app, resources={r"*/api/*": {"origins": "*"}})
    # CORS Headers
    @app.after_request
    def after_request(response):
        #response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization,true')
        #response.headers.add('Access-Control-Allow-Methods', 'GET,PATCH,POST,DELETE,OPTIONS')
        response.headers['Access-Control-Allow-Origin'] = '*'
        return response
    fakedb = []


    app.config.from_mapping(SECRET_KEY='dev',DATABASE=os.path.join(app.instance_path, 'flaskr.sqlite'))
    if test_config is None:
        # load the instance config, if it exists, when not testing
        app.config.from_pyfile('config.py', silent=True)
    else:
         # load the test config if passed in
         app.config.from_mapping(test_config)

    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    @app.route('/')
    def home():
        books = Book.query.all()
        formated_books = [book.format() for book in books]
        #result = Book.format(books)
        #book = Book.query.filter_by(title='Hi').first()
        #book = Book.query.all()
        return jsonify({'code':200,'books':formated_books,'total_books':len(formated_books)})


    def pagination_checker(page,selection):
        start = (page - 1) * book_per_page
        end = start + book_per_page
        formated_books = [book.format() for book in selection]
        pagie_list = formated_books[start:end]
        if len(pagie_list) == 0:
            return False
        else:
            return True

    def pagination_helper(request,selection):
        page = request.args.get('page',1,type=int)
        start = (page - 1) * book_per_page
        end = start + book_per_page
        formated_books = [book.format() for book in selection]
        pagie_list = formated_books[start:end]
        return pagie_list


    @app.route('/books')
    def page():
        last_page = 1
        books = Book.query.order_by('id').all()
        books_per_request = pagination_helper(request,books)
        books_count = len(books)
        books_in_request_count = len(books_per_request)
        if len(books_per_request) == 0:
            if books_count > book_per_page:
                last_page = round(int(books_count) / int(book_per_page))
                if (books_count / last_page) > book_per_page:
                    last_page = last_page + 1
            # this will return real server error not code and message defined use number to get any error
            #abort(404)
            response = make_response(jsonify(message="Hello, page paramter value exceeded books count try To solve it Last page is:%s" %last_page), 404)
            return response
        return jsonify({'code':200,'books':books_per_request,'total_books':books_count,'success':True})

    # update a book
    @app.route('/books/<int:book_id>', methods=['PATCH'])
    def update_book(book_id):
        body = request.get_json()
        try:
            book = Book.query.filter_by(id=book_id).one_or_none()
            if book is None:
                response = make_response(jsonify(message="Hello, We Did not Found that book try another one"), 404)
                return response
            if 'rating' in body:
                book.rating = int(body.get('rating'))
            #return str(book.rating)
            book.update()
            return jsonify({'code':200,
            'id':book.id,
            'book_rating':book.rating,
            'success':True})
        except:
            response = make_response(jsonify(message="Hello, this is a Bad Request Error  the server was unable to process the request sent by the client due to invalid syntax "), 400)
            return response


    # delete a book
    @app.route('/books/<int:book_id>', methods=['DELETE'])
    def delete_book(book_id):
        try:
            book = Book.query.filter_by(id=book_id).one_or_none()
            if book is None:
                response = make_response(jsonify(message="Hello, We Did not Found that book try another one"), 404)
                return response

            book.delete()
            selection = Book.query.order_by('id').all()
            current_books = pagination_helper(request,selection)
            len_books = len(selection)
            return jsonify({'code':200,
            'success':True,
            'books':current_books,
            'total_books':len_books})
        except:
            response = make_response(jsonify(message="Hello, this is a Bad Request Error  the server was unable to process the request sent by the client due to invalid syntax "), 400)
            return response

    # create new Book
    @app.route('/books', methods=['POST'])
    def create_book():
        body = request.get_json()
        # if title get it else make it None make sure title is nullable in DB
        title = body.get('title', None)
        author = body.get('author', None)
        rating = body.get('rating', None)
        try:
            newbook = Book(title=title, author=author,rating=rating)
            newbook.insert()

            selection = Book.query.order_by('id').all()
            current_books = pagination_helper(request, selection)
            len_books = len(selection)
            return jsonify({'code':200,'success':True,
            'books':current_books,'total_books':len_books,
            'created':newbook.id})
        except:
            response = make_response(jsonify(message="Hello, the server understands the content type of the request entity,\
            and the syntax of the request entity is correct, but it was unable to process the contained instructions"), 422)
            return response
        #print('Data Received: "{data}"'.format(data=data))

    # handle form request
    @app.route('/form', methods=['POST'])
    def home_form():
            if request.method == 'POST':
                x = request.form['hello']
                return jsonify({'messsage':x})
    # handle file request
    @app.route('/file', methods=['POST'])
    def home_file():
            if request.method == 'POST':

                file = request.files['test']
                filename=secure_filename(file.filename)
                return jsonify({'messsage':filename})



    return app
