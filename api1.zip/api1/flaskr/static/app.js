let sectionList = document.querySelectorAll('section');
let element = document.querySelector('ul');
let fragment = document.createDocumentFragment();
let options = { root:null,rootMargin: '0px',threshold: 0.1};


for (var section of sectionList){
let newlist= document.createElement('li');

let anchorLinkp1 = section.getAttribute('data-nav');
let l = document.createElement('a');

l.addEventListener('click', function(){
section.scrollIntoView({behavior:'smooth'});

console.log('I scrolled to Section' + anchorLinkp1)});

t = document.createTextNode(anchorLinkp1);
l.appendChild(t);
newlist.appendChild(l);
fragment.appendChild(newlist);
}

element.appendChild(fragment);

// if rquest.filter

// https://www.muscleandstrength.com/store/promos/index/filter
